@echo off
rem Instalador del agente local del radar. Uso: doble clic.
call "%~dp0agente_local\instalacion\instalar.cmd"
